#ifndef COUNTHEADS_H
#define COUNTHEADS_H

long int choose(int N, int r);
#endif
